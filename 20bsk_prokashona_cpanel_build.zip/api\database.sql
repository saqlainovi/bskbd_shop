-- =============================================================================
-- Bishwo Shahitto Kendro (BSK) Online Bookshop Database Schema
-- Production Ready MySQL Script for cPanel / phpMyAdmin
-- Database: bsk_bookshop_db
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Books Table
DROP TABLE IF EXISTS `bsk_books`;
CREATE TABLE `bsk_books` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `slug` VARCHAR(150) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `title_en` VARCHAR(255) DEFAULT '',
  `author` VARCHAR(255) NOT NULL,
  `translator` VARCHAR(255) DEFAULT '',
  `editor` VARCHAR(255) DEFAULT '',
  `category_id` VARCHAR(100) NOT NULL,
  `category_name` VARCHAR(150) NOT NULL,
  `series_id` VARCHAR(100) DEFAULT '',
  `series_name` VARCHAR(150) DEFAULT '',
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `regular_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `discount_percent` INT DEFAULT 0,
  `in_stock` TINYINT(1) NOT NULL DEFAULT 1,
  `stock_quantity` INT NOT NULL DEFAULT 50,
  `cover_image` VARCHAR(500) DEFAULT '',
  `cover_theme` VARCHAR(50) DEFAULT 'gold',
  `edition` VARCHAR(100) DEFAULT '১ম সংস্করণ',
  `pages` INT DEFAULT 200,
  `isbn` VARCHAR(50) DEFAULT '',
  `language` VARCHAR(50) DEFAULT 'বাংলা',
  `rating` DECIMAL(3,2) DEFAULT 4.80,
  `rating_count` INT DEFAULT 25,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Categories Table
DROP TABLE IF EXISTS `bsk_categories`;
CREATE TABLE `bsk_categories` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `slug` VARCHAR(100) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `subtitle` VARCHAR(255) DEFAULT '',
  `description` TEXT,
  `icon` VARCHAR(100) DEFAULT 'book',
  `book_count` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Customer Orders Table
DROP TABLE IF EXISTS `bsk_orders`;
CREATE TABLE `bsk_orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_number` VARCHAR(50) NOT NULL UNIQUE,
  `customer_name` VARCHAR(255) NOT NULL,
  `customer_phone` VARCHAR(50) NOT NULL,
  `customer_email` VARCHAR(150) DEFAULT '',
  `shipping_address` TEXT NOT NULL,
  `district` VARCHAR(100) DEFAULT '',
  `division` VARCHAR(100) DEFAULT '',
  `payment_method` VARCHAR(50) DEFAULT 'ক্যাশ অন ডেলিভারি',
  `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `shipping_fee` DECIMAL(10,2) NOT NULL DEFAULT 60.00,
  `status` ENUM('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
  `items_json` LONGTEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Admin Users Table
DROP TABLE IF EXISTS `bsk_admin_users`;
CREATE TABLE `bsk_admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `role` VARCHAR(50) DEFAULT 'admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Default Admin
INSERT INTO `bsk_admin_users` (`username`, `password_hash`, `name`, `email`, `role`) 
VALUES ('admin', 'bsk@admin2026', 'বিশ্বসাহিত্য কেন্দ্র অ্যাডমিন', 'admin@bskbd.org', 'superadmin');

-- Seed Sample Order
INSERT INTO `bsk_orders` (`order_number`, `customer_name`, `customer_phone`, `customer_email`, `shipping_address`, `district`, `division`, `payment_method`, `total_amount`, `shipping_fee`, `status`, `items_json`)
VALUES ('BSK-ORD-1001', 'তানভীর আহমেদ', '০১৭xxxxxxxx', 'tanvir@example.com', 'ধানমন্ডি ৩২, ঢাকা', 'ঢাকা', 'ঢাকা', 'ক্যাশ অন ডেলিভারি', 510.00, 60.00, 'processing', '[{"id":"bsk-101","title":"পথের পাঁচালী","price":240,"qty":1},{"id":"bsk-401","title":"কিশোর আনন্দ [প্রথম খণ্ড]","price":210,"qty":1}]');

-- Seed Categories
INSERT INTO `bsk_categories` (`id`, `slug`, `name`, `subtitle`, `description`, `icon`, `book_count`) VALUES ("bangla-literature", "bangla-sahitya", "বাংলা সাহিত্য", "গল্প, উপন্যাস, কবিতা, প্রবন্ধ, নাটক, রম্যরচনা, জীবনী", "গল্প, উপন্যাস, কবিতা, প্রবন্ধ, নাটক, রম্যরচনা ও জীবনীসহ বাংলা সাহিত্যের নির্বাচিত গ্রন্থসম্ভার।", "original-book", 6);
INSERT INTO `bsk_categories` (`id`, `slug`, `name`, `subtitle`, `description`, `icon`, `book_count`) VALUES ("world-literature", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "উপন্যাস, গল্প, নাটক ও অনুবাদ", "বিশ্বের নানা ভাষার কালজয়ী উপন্যাস, গল্প ও নাটকের প্রাঞ্জল বাংলা অনুবাদ।", "original-reader", 6);
INSERT INTO `bsk_categories` (`id`, `slug`, `name`, `subtitle`, `description`, `icon`, `book_count`) VALUES ("kids-literature", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "গল্প-উপন্যাস, রূপকথা ও ছড়া-কবিতা", "শিশু ও কিশোরদের কৌতূহল, কল্পনা ও আনন্দপাঠের উপযোগী গল্প-উপন্যাস, রূপকথা ও ছড়া-কবিতা।", "original-book-sign", 6);
INSERT INTO `bsk_categories` (`id`, `slug`, `name`, `subtitle`, `description`, `icon`, `book_count`) VALUES ("essays-thought", "probondho-monon", "প্রবন্ধ ও মনন", "চিন্তামূলক রচনা, দর্শন ও সাহিত্যচিন্তা", "চিন্তামূলক রচনা, সাহিত্যসমালোচনা, দর্শন ও মননশীল প্রবন্ধ সংকলন।", "book-open", 3);
INSERT INTO `bsk_categories` (`id`, `slug`, `name`, `subtitle`, `description`, `icon`, `book_count`) VALUES ("history-heritage", "itihash-o-oitijhyo", "ইতিহাস ও ঐতিহ্য", "ইতিহাস, সংস্কৃতি ও সভ্যতা", "বাংলার ইতিহাস, বিশ্বসভ্যতা ও সাংস্কৃতিক ঐতিহ্য বিষয়ক গ্রন্থসম্ভার।", "landmark", 2);
INSERT INTO `bsk_categories` (`id`, `slug`, `name`, `subtitle`, `description`, `icon`, `book_count`) VALUES ("special-series", "gronthomala", "গ্রন্থমালা", "কিশোর আনন্দ ও Reading for Pleasure", "ধারাবাহিক পাঠের আনন্দকে সমৃদ্ধ করতে কিশোর আনন্দ ও Reading for Pleasure গ্রন্থমালা।", "original-bookshelf", 4);

-- Seed Books
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-101", "bsk-101", "পথের পাঁচালী", "Pather Panchali", "বিভূতিভূষণ বন্দ্যোপাধ্যায়", "", "আবদুল্লাহ আবু সায়ীদ (ভূমিকা)", "bangla-sahitya", "বাংলা সাহিত্য", "", "", 240, 320, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "বিশ্বসাহিত্য কেন্দ্র প্রামাণ্য সংস্করণ", 312, "978-984-8001-01-2", "বাংলা", 4.9, 42, "বাংলার গ্রামীণ জীবন, শৈশবের বিস্ময় এবং অপু-দুর্গার চিরন্তন কাহিনি নিয়ে রচিত বিভূতিভূষণ বন্দ্যোপাধ্যায়ের কালজয়ী উপন্যাস। বিশ্বসাহিত্য কেন্দ্রের পরিমার্জিত ও প্রামাণ্য মুদ্রণ।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-102", "bsk-102", "অপরাজিত", "Aparajito", "বিভূতিভূষণ বন্দ্যোপাধ্যায়", "", "", "bangla-sahitya", "বাংলা সাহিত্য", "", "", 270, 360, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "চিরায়ত বাংলা সংস্করণ", 368, "978-984-8001-07-4", "বাংলা", 4.9, 24, "‘পথের পাঁচালী’র পরবর্তী পর্বে অপুর কৈশোর, যৌবন, জীবনসংগ্রাম ও আত্মজয়ের মহাকাব্যিক উপন্যাস ‘অপরাজিত’।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-103", "bsk-103", "আরণ্যক", "Aranyak", "বিভূতিভূষণ বন্দ্যোপাধ্যায়", "", "", "bangla-sahitya", "বাংলা সাহিত্য", "", "", 225, 300, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "চিরায়ত বাংলা সংস্করণ", 272, "978-984-8001-08-1", "বাংলা", 4.9, 33, "অরণ্যপ্রকৃতির অপার সৌন্দর্য এবং অরণ্যচারী মানুষের সহজ-সরল জীবনযাত্রার এক অনবদ্য কথামালা ‘আরণ্যক’।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-104", "bsk-104", "কপালকুণ্ডলা", "Kapalkundala", "বঙ্কিমচন্দ্র চট্টোপাধ্যায়", "", "আবদুল্লাহ আবু সায়ীদ (সম্পাদিত)", "bangla-sahitya", "বাংলা সাহিত্য", "", "", 150, 200, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "brick", "প্রামাণ্য সংস্করণ", 160, "978-984-8001-09-8", "বাংলা", 4.8, 19, "বঙ্কিমচন্দ্র চট্টোপাধ্যায়ের কালজয়ী রোমান্টিক উপন্যাস ‘কপালকুণ্ডলা’। নবকুমার ও কপালকুণ্ডলার চিরচেনা কাহিনির প্রামাণ্য সংস্করণ।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-105", "bsk-105", "গোরা", "Gora", "রবীন্দ্রনাথ ঠাকুর", "", "", "bangla-sahitya", "বাংলা সাহিত্য", "", "", 330, 440, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "অখণ্ড সংস্করণ", 432, "978-984-8001-10-4", "বাংলা", 5, 28, "স্বদেশচিন্তা, মানবধর্ম, সংস্কার ও আত্মপরিচয়ের দ্বন্দ্ব নিয়ে রবীন্দ্রনাথ ঠাকুরের মহত্তম শিল্পকর্ম ‘গোরা’।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-106", "bsk-106", "ঘরে বাইরে", "Ghare Baire", "রবীন্দ্রনাথ ঠাকুর", "", "", "bangla-sahitya", "বাংলা সাহিত্য", "", "", 180, 240, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "চিরায়ত বাংলা সংস্করণ", 208, "978-984-8001-11-1", "বাংলা", 4.8, 22, "নিখিলেশ, বিমলা ও সন্দীপের আত্মকথনের মধ্য দিয়ে ব্যক্তিহৃদয় ও রাজনীতির জটিল টানাপোড়েনের কালজয়ী উপন্যাস।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-201", "bsk-201", "সিদ্ধার্থ", "Siddhartha", "হেরমান হেসে", "জাভেদ হুসেন", "", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "", "", 165, 220, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "brick", "চিরায়ত বিশ্বসাহিত্য সংস্করণ", 168, "978-984-8001-03-6", "বাংলা", 4.9, 31, "নোবেলজয়ী কথাসাহিত্যিক হেরমান হেসের বিশ্ববিখ্যাত দার্শনিক উপন্যাস ‘সিদ্ধার্থ’। আত্মঅন্বেষণ ও জীবনবোধের এক অনন্য আখ্যান।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-202", "bsk-202", "মা", "Mother", "ম্যাক্সিম গোর্কি", "পুষ্পময়ী বসু", "", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "", "", 270, 360, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "চিরায়ত বিশ্বসাহিত্য সংস্করণ", 352, "978-984-8001-12-8", "বাংলা", 4.9, 36, "বিশ্বসাহিত্যের ইতিহাসে অন্যতম প্রভাবশালী উপন্যাস ম্যাক্সিম গোর্কির ‘মা’। মানবমুক্তি ও মাতৃহৃদয়ের অসামান্য আখ্যান।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-203", "bsk-203", "আনা কারেনিনা", "Anna Karenina", "লিও তলস্তয়", "ননী ভৌমিক", "", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "", "", 390, 520, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "অখণ্ড অনুবাদ সংস্করণ", 512, "978-984-8001-13-5", "বাংলা", 5, 27, "রুশ কথাসাহিত্যিক লিও তলস্তয়ের অমর সৃষ্টি ‘আনা কারেনিনা’। উনিশ শতকের রুশ সমাজ ও মানবসম্পর্কের অতুলনীয় মহাকাব্য।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-204", "bsk-204", "যুদ্ধ ও শান্তি", "War and Peace", "লিও তলস্তয়", "ননী ভৌমিক", "", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "", "", 420, 560, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "brick", "নির্বাচিত সংস্করণ", 540, "978-984-8001-14-2", "বাংলা", 4.9, 21, "ইতিহাস, যুদ্ধ, দর্শন ও পারিবারিক জীবনের বিশাল ক্যানভাসে রচিত বিশ্বসাহিত্যের সর্বকালের অন্যতম শ্রেষ্ঠ উপন্যাস।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-205", "bsk-205", "অপরাধ ও শাস্তি", "Crime and Punishment", "ফিওদর দস্তয়েভস্কি", "অরুণ সোম", "", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "", "", 360, 480, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "চিরায়ত বিশ্বসাহিত্য সংস্করণ", 464, "978-984-8001-15-9", "বাংলা", 5, 30, "মানুষের বিবেক, অপরাধবোধ ও মনস্তত্ত্বের গভীরতম বিশ্লেষণ নিয়ে দস্তয়েভস্কির কালজয়ী উপন্যাস।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-206", "bsk-206", "দ্য ওল্ড ম্যান অ্যান্ড দ্য সি", "The Old Man and the Sea", "আর্নেস্ট হেমিংওয়ে", "ফতেহ লোহানী", "", "bishwo-sahitya-onubad", "বিশ্বসাহিত্য ও অনুবাদ", "", "", 135, 180, 25, 0, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "পরিমার্জিত সংস্করণ", 136, "978-984-8001-16-6", "বাংলা", 4.8, 18, "সমুদ্রের বুকে বৃদ্ধ জেলে সান্তিয়াগোর অদম্য জীবনসংগ্রাম ও অপরাজেয় মানবিক চেতনার অমর আখ্যান।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-301", "bsk-301", "টুনটুনির বই", "Tuntunir Boi", "উপেন্দ্রকিশোর রায়চৌধুরী", "", "", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "", "", 135, 180, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "brick", "শিশু-কিশোর আনন্দপাঠ সংস্করণ", 128, "978-984-8001-05-0", "বাংলা", 4.9, 35, "বাংলা শিশুসাহিত্যের চিরসবুজ রূপকথা ও পশুপাখির মজার গল্পের কালজয়ী সংকলন ‘টুনটুনির বই’।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-302", "bsk-302", "আবোল তাবোল", "Abol Tabol", "সুকুমার রায়", "", "", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "", "", 120, 160, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "সচিত্র সংস্করণ", 112, "978-984-8001-17-3", "বাংলা", 5, 40, "সুকুমার রায়ের অনন্য ছড়া ও অলংকরণের চিরকালের প্রিয় সংকলন ‘আবোল তাবোল’—ছোট-বড় সবার আনন্দপাঠ।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-303", "bsk-303", "পাগলা দাশু", "Pagla Dashu", "সুকুমার রায়", "", "", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "", "", 128, 170, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "শিশু-কিশোর সংস্করণ", 124, "978-984-8001-18-0", "বাংলা", 4.9, 26, "স্কুলজীবনের নির্মল হাস্যরস ও পাগলা দাশুর মজার কাণ্ডকারখানা নিয়ে কিশোরদের চিরপ্রিয় গল্পগ্রন্থ।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-304", "bsk-304", "চাঁদের পাহাড়", "Chander Pahar", "বিভূতিভূষণ বন্দ্যোপাধ্যায়", "", "", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "", "", 165, 220, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "brick", "কিশোর অভিযান সংস্করণ", 176, "978-984-8001-19-7", "বাংলা", 5, 44, "বাংলার তরুণ শঙ্করের আফ্রিকার রহস্যঘন অরণ্য ও রিকটারসভেল্ড পর্বতে দুঃসাহসিক অভিযানের রোমাঞ্চকর কাহিনি।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-305", "bsk-305", "ক্ষীরের পুতুল", "Khirer Putul", "অবনীন্দ্রনাথ ঠাকুর", "", "", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "", "", 113, 150, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "সচিত্র রূপকথা সংস্করণ", 96, "978-984-8001-20-3", "বাংলা", 4.8, 20, "দুয়োরানি, সুয়োরানি ও চতুর বানরের জাদুকরী রূপকথা—বাংলা শিশুসাহিত্যের এক অমূল্য রত্ন।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-306", "bsk-306", "হ্যঁস ক্রিশ্চিয়ান অ্যান্ডারসনের রূপকথা", "Hans Christian Andersen Fairy Tales", "হ্যঁস ক্রিশ্চিয়ান অ্যান্ডারসেন", "বিশ্বসাহিত্য কেন্দ্র সম্পাদনা পর্ষদ", "আবদুল্লাহ আবু সায়ীদ", "shishu-kishor", "শিশু-কিশোর সাহিত্য", "", "", 180, 240, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "বিশ্বরূপকথা সংস্করণ", 192, "978-984-8001-21-0", "বাংলা", 4.9, 23, "ডেনমার্কের বিশ্বখ্যাত রূপকথাকার হ্যঁস ক্রিশ্চিয়ান অ্যান্ডারসনের নির্বাচিত রূপকথার সহজ ও প্রাঞ্জল বাংলা অনুবাদ।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-401", "bsk-401", "কিশোর আনন্দ [প্রথম খণ্ড]", "Kishor Anondo - Vol 1", "বিশ্বসাহিত্য কেন্দ্র সংকলন", "", "আবদুল্লাহ আবু সায়ীদ", "gronthomala", "গ্রন্থমালা", "kishor-anondo", "কিশোর আনন্দ", 210, 280, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "বিশেষ গ্রন্থমালা সংস্করণ", 256, "978-984-8001-04-3", "বাংলা", 4.9, 29, "কিশোর পাঠকদের আনন্দপাঠ ও মনন বিকাশের লক্ষ্যে বাংলা ও বিশ্বসাহিত্যের নির্বাচিত গল্প, ভ্রমণ ও জীবনকথার অনন্য সংকলন।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-402", "bsk-402", "দেশে বিদেশে", "Deshe Bideshe", "সৈয়দ মুজতবা আলী", "", "আবদুল্লাহ আবু সায়ীদ (ভূমিকা)", "probondho-monon", "প্রবন্ধ ও মনন", "", "", 240, 320, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "প্রামাণ্য সংস্করণ", 264, "978-984-8001-06-7", "বাংলা", 5, 47, "বাংলা ভ্রমণসাহিত্যের চিরকালের শ্রেষ্ঠ গ্রন্থ সৈয়দ মুজতবা আলীর ‘দেশে বিদেশে’। কাবুল শহরের জীবন, ইতিহাস ও মানবিক রসবোধের অনন্য দলিল।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-403", "bsk-403", "কিশোর আনন্দ [দ্বিতীয় খণ্ড]", "Kishor Anondo - Vol 2", "বিশ্বসাহিত্য কেন্দ্র সংকলন", "", "আবদুল্লাহ আবু সায়ীদ", "gronthomala", "গ্রন্থমালা", "kishor-anondo", "কিশোর আনন্দ", 210, 280, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "brick", "বিশেষ গ্রন্থমালা সংস্করণ", 264, "978-984-8001-22-7", "বাংলা", 4.9, 19, "মাধ্যমিক পর্যায়ের কিশোর পাঠকদের উপযোগী নির্বাচিত গল্প, স্মৃতিকথা ও ভ্রমণকাহিনির দ্বিতীয় খণ্ড।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-404", "bsk-404", "Reading for Pleasure [Book 1]", "Reading for Pleasure - Book 1", "Bishwo Shahitto Kendro", "", "Editorial Board, BSK", "gronthomala", "গ্রন্থমালা", "reading-for-pleasure", "Reading for Pleasure", 180, 240, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "Revised Edition", 184, "978-984-8001-23-4", "বাংলা", 4.9, 25, "ইংরেজি ভাষা ও সাহিত্যের আনন্দপাঠকে সহজ ও আকর্ষণীয় করে তুলতে বিশ্বসাহিত্যের নির্বাচিত ক্লাসিক গল্পের প্রথম খণ্ড।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-405", "bsk-405", "Reading for Pleasure [Book 2]", "Reading for Pleasure - Book 2", "Bishwo Shahitto Kendro", "", "Editorial Board, BSK", "gronthomala", "গ্রন্থমালা", "reading-for-pleasure", "Reading for Pleasure", 195, 260, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "Revised Edition", 204, "978-984-8001-24-1", "বাংলা", 4.8, 21, "ও. হেনরি, গি দ্য মোপাসাঁ, আন্তন চেখভ ও অস্কার ওয়াইল্ডের নির্বাচিত ক্লাসিক ইংরেজি গল্পের সংকলন।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-406", "bsk-406", "নিষ্ফলা মাঠের কৃষক", "Nishphola Mather Krishok", "অধ্যাপক আবদুল্লাহ আবু সায়ীদ", "", "", "probondho-monon", "প্রবন্ধ ও মনন", "", "", 225, 300, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "gold", "প্রবন্ধ ও স্মৃতিকথা সংস্করণ", 240, "978-984-8001-25-8", "বাংলা", 5, 38, "অধ্যাপক আবদুল্লাহ আবু সায়ীদের অনন্য আত্মজৈবনিক ও মননশীল রচনা—শিক্ষকতা, সাহিত্য ও আলোকিত মানুষ গড়ার স্বপ্নযাত্রার অন্তর্দৃষ্টি।");
INSERT INTO `bsk_books` (`id`, `slug`, `title`, `title_en`, `author`, `translator`, `editor`, `category_id`, `category_name`, `series_id`, `series_name`, `price`, `regular_price`, `discount_percent`, `in_stock`, `stock_quantity`, `cover_image`, `cover_theme`, `edition`, `pages`, `isbn`, `language`, `rating`, `rating_count`, `description`) VALUES ("bsk-407", "bsk-407", "বিশ্বসাহিত্য কেন্দ্র : গড়ে ওঠার ইতিহাস", "Bishwo Shahitto Kendro: Gore Othar Itihash", "অধ্যাপক আবদুল্লাহ আবু সায়ীদ", "", "", "itihash-o-oitijhyo", "ইতিহাস ও ঐতিহ্য", "", "", 255, 340, 25, 1, 50, "/assets/img/product/product-img-5-1.jpg", "ink", "প্রাতিষ্ঠানিক ইতিহাস সংস্করণ", 288, "978-984-8001-26-5", "বাংলা", 5, 29, "একটি ছোট পাঠচক্র থেকে দেশব্যাপী আলোকিত মানুষ গড়ার আন্দোলনে পরিণত হওয়ার বাস্তব ও প্রেরণাদায়ী ইতিহাস।");

SET FOREIGN_KEY_CHECKS = 1;
