<?php
/**
 * Bishwo Shahitto Kendro (BSK) Online Bookshop
 * Database Connection Diagnostic & Auto-Save Tool
 * URL: https://shop.bskbd.org/api/test_db.php
 */

require_once __DIR__ . '/config/db.php';

$pdo = getDbConnection();
$db_error = getDbError();
$config = getDbConfig();
$save_result = null;

// Handle Auto-Save Database Credentials from Browser Form
if (isset($_POST['action']) && $_POST['action'] === 'save_credentials') {
    $new_host = trim($_POST['db_host'] ?? 'localhost');
    $new_name = trim($_POST['db_name'] ?? 'bskbd_shop');
    $new_user = trim($_POST['db_user'] ?? 'bskbd');
    $new_pass = trim($_POST['db_pass'] ?? '');

    try {
        $test_dsn = "mysql:host={$new_host};dbname={$new_name};charset=utf8mb4";
        $test_options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $test_pdo = new PDO($test_dsn, $new_user, $new_pass, $test_options);
        
        // Write cleanly to config/db.php
        $dbPhpContent = "<?php\n"
            . "/**\n * Bishwo Shahitto Kendro (BSK) Online Bookshop\n * Database Connection & Configuration Module\n */\n\n"
            . "error_reporting(E_ALL);\nini_set('display_errors', '0');\n\n"
            . "header('Access-Control-Allow-Origin: *');\n"
            . "header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');\n"
            . "header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');\n"
            . "header('Content-Type: application/json; charset=UTF-8');\n\n"
            . "if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') {\n    http_response_code(200);\n    exit();\n}\n\n"
            . "\$db_host = '" . addslashes($new_host) . "';\n"
            . "\$db_name = '" . addslashes($new_name) . "';\n"
            . "\$db_user = '" . addslashes($new_user) . "';\n"
            . "\$db_pass = '" . addslashes($new_pass) . "';\n\n"
            . "if (getenv('DB_NAME')) \$db_name = getenv('DB_NAME');\n"
            . "if (getenv('DB_USER')) \$db_user = getenv('DB_USER');\n"
            . "if (getenv('DB_PASS')) \$db_pass = getenv('DB_PASS');\n"
            . "if (getenv('DB_HOST')) \$db_host = getenv('DB_HOST');\n\n"
            . "\$pdo = null;\n\$db_error = null;\n\n"
            . "try {\n"
            . "    \$dsn = \"mysql:host={\$db_host};dbname={\$db_name};charset=utf8mb4\";\n"
            . "    \$options = [\n"
            . "        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,\n"
            . "        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,\n"
            . "        PDO::ATTR_EMULATE_PREPARES   => false,\n"
            . "    ];\n"
            . "    \$pdo = new PDO(\$dsn, \$db_user, \$db_pass, \$options);\n"
            . "} catch (PDOException \$e) {\n"
            . "    \$pdo = null;\n"
            . "    \$db_error = \$e->getMessage();\n"
            . "}\n\n"
            . "function getDbConnection() {\n    global \$pdo;\n    return \$pdo;\n}\n\n"
            . "function getDbError() {\n    global \$db_error;\n    return \$db_error;\n}\n\n"
            . "function getDbConfig() {\n    global \$db_host, \$db_name, \$db_user;\n    return ['host' => \$db_host, 'database' => \$db_name, 'user' => \$db_user];\n}\n";

        file_put_contents(__DIR__ . '/config/db.php', $dbPhpContent);
        $save_result = ['status' => 'success', 'message' => 'অভিনন্দন! ডাটাবেজ সফলভাবে কানেক্ট হয়েছে এবং api/config/db.php ফাইলে কনফিগারেশন স্বয়ংক্রিয়ভাবে সেভ হয়েছে!'];
        $pdo = $test_pdo;
        $db_error = null;
        $config = ['host' => $new_host, 'database' => $new_name, 'user' => $new_user];
    } catch (PDOException $e) {
        $save_result = ['status' => 'error', 'message' => 'কানেকশন ব্যর্থ হয়েছে: ' . $e->getMessage()];
    }
}

// Seed Action Execution
$seed_result = null;
if (isset($_POST['run_seed']) || isset($_GET['seed'])) {
    if (!$pdo) {
        $seed_result = ['status' => 'error', 'message' => 'ডাটাবেজ কানেক্ট করা সম্ভব হয়নি। আগে নিচের ফর্মে সঠিক পাসওয়ার্ড দিয়ে কানেক্ট করুন।'];
    } else {
        $sqlPath = __DIR__ . '/database.sql';
        if (!file_exists($sqlPath)) {
            $sqlPath = dirname(__DIR__) . '/database.sql';
        }
        if (!file_exists($sqlPath)) {
            $seed_result = ['status' => 'error', 'message' => 'database.sql ফাইলটি পাওয়া যায়নি।'];
        } else {
            try {
                $sqlContent = file_get_contents($sqlPath);
                $pdo->exec($sqlContent);
                $seed_result = ['status' => 'success', 'message' => 'অভিনন্দন! database.sql সফলভাবে এক্সিকিউট হয়েছে এবং সব টেবিল ও ২৫টি বই ইনস্টল করা হয়েছে।'];
            } catch (Exception $e) {
                $seed_result = ['status' => 'error', 'message' => 'SQL এক্সিকিউট করতে ত্রুটি: ' . $e->getMessage()];
            }
        }
    }
}

// Check Tables Count
$table_stats = [];
if ($pdo) {
    $tables = ['bsk_books' => 'বই', 'bsk_categories' => 'ক্যাটাগরি', 'bsk_orders' => 'অর্ডার', 'bsk_admin_users' => 'অ্যাডমিন ইউজার'];
    foreach ($tables as $t => $label) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM `{$t}`");
            $cnt = $stmt->fetch()['cnt'];
            $table_stats[$t] = ['label' => $label, 'count' => $cnt, 'exists' => true];
        } catch (Exception $e) {
            $table_stats[$t] = ['label' => $label, 'count' => 0, 'exists' => false];
        }
    }
}

// JSON format support
if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'connected' => $pdo !== null,
        'config' => $config,
        'error' => $db_error,
        'tables' => $table_stats,
        'save_result' => $save_result,
        'seed_result' => $seed_result
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit();
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BSK ডাটাবেজ কানেকশন ও সিঙ্ক প্যানেল</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
    body { background-color: #FAF7F2; color: #30261B; padding: 24px; line-height: 1.6; }
    .container { max-width: 860px; margin: 0 auto; background: #FFFFFF; border-radius: 16px; border: 1.5px solid #EAE1D2; box-shadow: 0 10px 30px rgba(48,38,27,0.06); overflow: hidden; }
    .header { background: #30261B; color: #FFFDF9; padding: 24px 30px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px; border-bottom: 3px solid #9A7224; }
    .header h1 { font-size: 22px; font-weight: 700; color: #E8C06B; }
    .header p { font-size: 14px; color: #D8CCC0; margin-top: 4px; }
    .body { padding: 30px; }
    .status-badge { display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 30px; font-size: 15px; font-weight: 700; }
    .status-badge.success { background: #E7F6EC; color: #157338; border: 1.5px solid #A3E2B8; }
    .status-badge.danger { background: #FDE8E8; color: #9B1C1C; border: 1.5px solid #F8B4B4; }
    .card { background: #FDFBF7; border: 1px solid #EAE1D2; border-radius: 12px; padding: 20px; margin-top: 20px; }
    .card-title { font-size: 17px; font-weight: 700; color: #30261B; margin-bottom: 12px; border-bottom: 1px solid #EAE1D2; padding-bottom: 8px; }
    .config-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-top: 10px; }
    .config-item { background: #FFFFFF; padding: 12px 14px; border-radius: 8px; border: 1px solid #EAE1D2; font-size: 14px; }
    .config-item span { display: block; color: #7B6E5F; font-size: 12px; margin-bottom: 4px; text-transform: uppercase; font-weight: 600; }
    .config-item strong { color: #30261B; font-size: 15px; }
    .table-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-top: 10px; }
    .table-item { background: #FFFFFF; padding: 16px; border-radius: 8px; border: 1.5px solid #EAE1D2; text-align: center; }
    .table-item.active { border-color: #9A7224; background: #FAF6ED; }
    .table-item h4 { font-size: 14px; color: #7B6E5F; }
    .table-item .count { font-size: 26px; font-weight: 800; color: #9A7224; margin: 6px 0; }
    .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 24px; border-radius: 8px; font-size: 15px; font-weight: 700; text-decoration: none; cursor: pointer; border: none; transition: all 0.2s; }
    .btn-gold { background: #9A7224; color: #FFFFFF; }
    .btn-gold:hover { background: #815E1D; color: #FFFFFF; }
    .btn-outline { background: transparent; border: 1.5px solid #9A7224; color: #9A7224; }
    .btn-outline:hover { background: #FAF6ED; }
    .alert { padding: 14px 18px; border-radius: 8px; margin-bottom: 20px; font-size: 14.5px; font-weight: 600; }
    .alert.success { background: #E7F6EC; color: #157338; border: 1px solid #A3E2B8; }
    .alert.danger { background: #FDE8E8; color: #9B1C1C; border: 1px solid #F8B4B4; }
    .form-group { margin-bottom: 14px; }
    .form-group label { display: block; font-size: 13.5px; font-weight: 600; color: #5C4E3F; margin-bottom: 6px; }
    .form-control { width: 100%; padding: 10px 14px; border: 1.5px solid #D8CCC0; border-radius: 8px; font-size: 14.5px; }
    .form-control:focus { outline: none; border-color: #9A7224; box-shadow: 0 0 0 3px rgba(154,114,36,0.15); }
    .links-bar { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 25px; padding-top: 20px; border-top: 1px solid #EAE1D2; }
  </style>
</head>
<body>
<div class="container">
  <div class="header">
    <div>
      <h1>বিশ্বসাহিত্য কেন্দ্র প্রকাশনা</h1>
      <p>MySQL ডাটাবেজ কানেকশন ও সিঙ্ক ডায়াগনস্টিক টুল</p>
    </div>
    <div>
      <?php if ($pdo): ?>
        <span class="status-badge success">● ডাটাবেজ সংযুক্ত (Active)</span>
      <?php else: ?>
        <span class="status-badge danger">● ডাটাবেজ অফলাইন (Offline)</span>
      <?php endif; ?>
    </div>
  </div>

  <div class="body">
    <?php if (!$pdo && $db_error): ?>
      <div class="alert danger" style="background: #FEE2E2; border: 1.5px solid #F87171; color: #991B1B;">
        ⚠️ <strong>ডাটাবেজ অফলাইন বার্তা:</strong> <?= htmlspecialchars($db_error) ?>
      </div>
    <?php endif; ?>

    <?php if ($save_result): ?>
      <div class="alert <?= $save_result['status'] === 'success' ? 'success' : 'danger' ?>">
        <?= htmlspecialchars($save_result['message']) ?>
      </div>
    <?php endif; ?>

    <?php if ($seed_result): ?>
      <div class="alert <?= $seed_result['status'] === 'success' ? 'success' : 'danger' ?>">
        <?= htmlspecialchars($seed_result['message']) ?>
      </div>
    <?php endif; ?>

    <!-- One-Click Browser Credential Save Form -->
    <div class="card" style="background: #FFFDF9; border: 2px solid #9A7224;">
      <div class="card-title" style="color: #9A7224;">⚡ ব্রাউজার থেকেই ডাটাবেজ কানেক্ট ও সেভ করুন (cPanel ফাইল এডিট ছাড়া)</div>
      
      <div style="background: #F8F5EE; border-left: 4px solid #9A7224; padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; font-size: 13.5px; line-height: 1.6; color: #4A3E31;">
        <strong>💡 পাসওয়ার্ড ভুলে গেলে বা না জানলে ১ মিনিটের সমাধান:</strong><br>
        ১. আপনার <strong>cPanel</strong>-এ যান ➔ <strong>MySQL® Databases</strong>-এ ক্লিক করুন।<br>
        ২. নিচে স্ক্রল করে <strong>Current Users</strong>-এ আপনার ইউজার (যেমন: <code>bskbd</code>)-এর পাশে <strong>Change Password</strong>-এ ক্লিক করে নতুন পাসওয়ার্ড দিন (যেমন: <code>Bsk@Shop2025</code>)।<br>
        ৩. <strong>Add User To Database</strong> অংশে User: <code>bskbd</code> ও Database: <code>bskbd_shop</code> সিলেক্ট করে <strong>Add</strong> চাপুন এবং <strong>ALL PRIVILEGES</strong> দিয়ে সেভ করুন।<br>
        ৪. এবার নিচে সেই পাসওয়ার্ডটি লিখে <strong>এক ক্লিকে কানেক্ট</strong> বাটনে চাপ দিন!
      </div>
      <form method="POST">
        <input type="hidden" name="action" value="save_credentials">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px;">
          <div class="form-group">
            <label>ডাটাবেজ হোস্ট (Host):</label>
            <input type="text" name="db_host" class="form-control" value="<?= htmlspecialchars($config['host'] ?: 'localhost') ?>" required>
          </div>
          <div class="form-group">
            <label>ডাটাবেজ নাম (Database):</label>
            <input type="text" name="db_name" class="form-control" value="<?= htmlspecialchars($config['database'] ?: 'bskbd_shop') ?>" required>
          </div>
          <div class="form-group">
            <label>ডাটাবেজ ইউজার (User):</label>
            <input type="text" name="db_user" class="form-control" value="<?= htmlspecialchars($config['user'] ?: 'bskbd') ?>" required>
          </div>
          <div class="form-group">
            <label>ডাটাবেজ পাসওয়ার্ড (Password):</label>
            <input type="password" name="db_pass" class="form-control" placeholder="আপনার cPanel ডাটাবেজের পাসওয়ার্ড">
          </div>
        </div>
        <button type="submit" class="btn btn-gold" style="width: 100%; margin-top: 10px;">
          💾 এক ক্লিকে কানেক্ট ও কনফিগারেশন সেভ করুন
        </button>
      </form>
    </div>

    <!-- Tables Status Card -->
    <?php if ($pdo): ?>
      <div class="card">
        <div class="card-title">ডাটাবেজ টেবিল ও তথ্যের পরিসংখ্যান (Database: <?= htmlspecialchars($config['database']) ?>)</div>
        <div class="table-grid">
          <?php foreach ($table_stats as $tbl => $info): ?>
            <div class="table-item <?= $info['exists'] ? 'active' : '' ?>">
              <h4><?= htmlspecialchars($info['label']) ?> (<?= htmlspecialchars($tbl) ?>)</h4>
              <div class="count"><?= $info['count'] ?></div>
              <small style="color: <?= $info['exists'] ? '#157338' : '#C53030' ?>; font-weight: 600;">
                <?= $info['exists'] ? '✓ টেবিল প্রস্তুত' : '✕ টেবিল নেই' ?>
              </small>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Quick Navigation Links -->
    <div class="links-bar">
      <a href="/" class="btn btn-gold">🏠 হোমপেজ</a>
      <a href="/shop" class="btn btn-outline">📚 সকল বই (/shop)</a>
      <a href="/categories" class="btn btn-outline">📑 বিষয়ভিত্তিক বই (/categories)</a>
      <a href="/series" class="btn btn-outline">📖 গ্রন্থমালা (/series)</a>
      <a href="/admin" class="btn btn-outline">⚙️ অ্যাডমিন প্যানেল (/admin)</a>
    </div>
  </div>
</div>
</body>
</html>
