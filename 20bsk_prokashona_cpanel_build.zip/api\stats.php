<?php
/**
 * Bishwo Shahitto Kendro (BSK) Online Bookshop
 * Admin Analytics & Summary Stats API
 */

require_once __DIR__ . '/config/db.php';

$pdo = getDbConnection();

if (!$pdo) {
    echo json_encode([
        'totalBooks' => 25,
        'inStockBooks' => 24,
        'outOfStockBooks' => 1,
        'totalOrders' => 1,
        'totalRevenue' => 510,
        'databaseConnected' => false,
    ]);
    exit();
}

try {
    $booksCount = $pdo->query("SELECT COUNT(*) FROM bsk_books")->fetchColumn();
    $inStockCount = $pdo->query("SELECT COUNT(*) FROM bsk_books WHERE in_stock = 1")->fetchColumn();
    $outOfStockCount = $pdo->query("SELECT COUNT(*) FROM bsk_books WHERE in_stock = 0")->fetchColumn();
    $ordersCount = $pdo->query("SELECT COUNT(*) FROM bsk_orders")->fetchColumn();
    $revenue = $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM bsk_orders WHERE status != 'cancelled'")->fetchColumn();

    echo json_encode([
        'totalBooks' => intval($booksCount),
        'inStockBooks' => intval($inStockCount),
        'outOfStockBooks' => intval($outOfStockCount),
        'totalOrders' => intval($ordersCount),
        'totalRevenue' => floatval($revenue),
        'databaseConnected' => true,
    ]);
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'databaseConnected' => false,
    ]);
}
