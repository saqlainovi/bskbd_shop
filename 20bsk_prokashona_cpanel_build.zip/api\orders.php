<?php
/**
 * Bishwo Shahitto Kendro (BSK) Online Bookshop
 * Orders REST API: GET, POST, PUT
 */

require_once __DIR__ . '/config/db.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];

if (!$pdo) {
    if ($method === 'GET') {
        echo json_encode([]);
        exit();
    } else {
        echo json_encode(['status' => 'success', 'orderNumber' => 'BSK-ORD-' . substr(time(), -4)]);
        exit();
    }
}

// GET: All Orders
if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM bsk_orders ORDER BY created_at DESC");
    $orders = $stmt->fetchAll();

    $mapped = array_map(function($o) {
        return [
            'id' => $o['order_number'],
            'orderNumber' => $o['order_number'],
            'customerName' => $o['customer_name'],
            'customerPhone' => $o['customer_phone'],
            'customerEmail' => $o['customer_email'],
            'shippingAddress' => $o['shipping_address'],
            'district' => $o['district'],
            'division' => $o['division'],
            'paymentMethod' => $o['payment_method'],
            'totalAmount' => floatval($o['total_amount']),
            'shippingFee' => floatval($o['shipping_fee']),
            'status' => $o['status'],
            'createdAt' => $o['created_at'],
            'items' => json_decode($o['items_json'] ?? '[]', true),
        ];
    }, $orders);

    echo json_encode($mapped);
    exit();
}

// POST: Place New Order
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid order payload']);
        exit();
    }

    $orderNum = $data['orderNumber'] ?? 'BSK-ORD-' . substr(time(), -4);
    $name = $data['customerName'] ?? 'নামবিহীন গ্রাহক';
    $phone = $data['customerPhone'] ?? '';
    $email = $data['customerEmail'] ?? '';
    $address = $data['shippingAddress'] ?? '';
    $district = $data['district'] ?? '';
    $division = $data['division'] ?? '';
    $payMethod = $data['paymentMethod'] ?? 'ক্যাশ অন ডেলিভারি';
    $total = floatval($data['totalAmount'] ?? 0);
    $fee = floatval($data['shippingFee'] ?? 60);
    $items = json_encode($data['items'] ?? []);

    $stmt = $pdo->prepare("INSERT INTO bsk_orders 
        (order_number, customer_name, customer_phone, customer_email, shipping_address, district, division, payment_method, total_amount, shipping_fee, status, items_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)");

    $stmt->execute([$orderNum, $name, $phone, $email, $address, $district, $division, $payMethod, $total, $fee, $items]);

    echo json_encode(['status' => 'success', 'orderNumber' => $orderNum]);
    exit();
}

// PUT: Update Order Status
if ($method === 'PUT') {
    $id = $_GET['id'] ?? null;
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$id || !isset($data['status'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Order ID and status required']);
        exit();
    }

    $stmt = $pdo->prepare("UPDATE bsk_orders SET status = ? WHERE order_number = ? OR id = ?");
    $stmt->execute([$data['status'], $id, $id]);

    echo json_encode(['status' => 'success', 'message' => 'Order status updated']);
    exit();
}
