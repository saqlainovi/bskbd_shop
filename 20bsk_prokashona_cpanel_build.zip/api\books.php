<?php
/**
 * Bishwo Shahitto Kendro (BSK) Online Bookshop
 * Books REST API Endpoint: GET, POST, PUT, DELETE
 */

require_once __DIR__ . '/config/db.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];

// If PDO is not connected (e.g. database not yet created in cPanel), return mock fallback
if (!$pdo) {
    if ($method === 'GET') {
        // Return 200 with empty array or mock status so React gracefully uses localStorage
        echo json_encode(['status' => 'offline_mode', 'message' => 'Database offline. Using localStorage client sync.']);
        exit();
    } else {
        echo json_encode(['status' => 'success', 'message' => 'Saved locally (database offline).']);
        exit();
    }
}

// -----------------------------------------------------------------------------
// GET: Fetch Books (all, by id, by category, or by series)
// -----------------------------------------------------------------------------
if ($method === 'GET') {
    $id = $_GET['id'] ?? null;
    $category = $_GET['category'] ?? null;
    $series = $_GET['series'] ?? null;
    $search = $_GET['search'] ?? null;

    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM bsk_books WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $book = $stmt->fetch();
        if ($book) {
            echo json_encode($book);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Book not found']);
        }
        exit();
    }

    $sql = "SELECT * FROM bsk_books WHERE 1=1";
    $params = [];

    if ($category && $category !== 'all') {
        $sql .= " AND (category_id = ? OR category_name = ?)";
        $params[] = $category;
        $params[] = $category;
    }

    if ($series && $series !== 'all') {
        $sql .= " AND (series_id = ? OR series_name = ?)";
        $params[] = $series;
        $params[] = $series;
    }

    if ($search) {
        $sql .= " AND (title LIKE ? OR author LIKE ? OR category_name LIKE ?)";
        $term = "%{$search}%";
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    $sql .= " ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();

    // Map column names to camelCase for frontend compatibility
    $mapped = array_map(function($b) {
        return [
            'id' => $b['id'],
            'slug' => $b['slug'],
            'title' => $b['title'],
            'titleEn' => $b['title_en'],
            'author' => $b['author'],
            'translator' => $b['translator'],
            'editor' => $b['editor'],
            'category' => $b['category_id'],
            'categoryId' => $b['category_id'],
            'categoryName' => $b['category_name'],
            'series' => $b['series_id'],
            'seriesId' => $b['series_id'],
            'seriesName' => $b['series_name'],
            'price' => floatval($b['price']),
            'regularPrice' => floatval($b['regular_price']),
            'discountPercent' => intval($b['discount_percent']),
            'inStock' => boolval($b['in_stock']),
            'stockQuantity' => intval($b['stock_quantity']),
            'coverImage' => $b['cover_image'],
            'coverTheme' => $b['cover_theme'],
            'edition' => $b['edition'],
            'pages' => intval($b['pages']),
            'isbn' => $b['isbn'],
            'language' => $b['language'],
            'rating' => floatval($b['rating']),
            'ratingCount' => intval($b['rating_count']),
            'description' => $b['description'],
        ];
    }, $books);

    echo json_encode($mapped);
    exit();
}

// -----------------------------------------------------------------------------
// POST: Add New Book
// -----------------------------------------------------------------------------
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || empty($data['title']) || empty($data['author'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Title and Author are required']);
        exit();
    }

    $id = $data['id'] ?? 'bsk-' . substr(time(), -4);
    $slug = $data['slug'] ?? $id;
    $title = $data['title'];
    $titleEn = $data['titleEn'] ?? '';
    $author = $data['author'];
    $translator = $data['translator'] ?? '';
    $editor = $data['editor'] ?? '';
    $categoryId = $data['categoryId'] ?? $data['category'] ?? 'bangla-sahitya';
    $categoryName = $data['categoryName'] ?? 'বাংলা সাহিত্য';
    $seriesId = $data['seriesId'] ?? $data['series'] ?? '';
    $seriesName = $data['seriesName'] ?? '';
    $price = floatval($data['price'] ?? 200);
    $regularPrice = floatval($data['regularPrice'] ?? $price);
    $discountPercent = intval($data['discountPercent'] ?? 0);
    $inStock = isset($data['inStock']) ? ($data['inStock'] ? 1 : 0) : 1;
    $stockQuantity = intval($data['stockQuantity'] ?? 50);
    $coverImage = $data['coverImage'] ?? '/assets/img/product/product-img-5-1.jpg';
    $coverTheme = $data['coverTheme'] ?? 'gold';
    $edition = $data['edition'] ?? '১ম সংস্করণ';
    $pages = intval($data['pages'] ?? 200);
    $isbn = $data['isbn'] ?? '';
    $language = $data['language'] ?? 'বাংলা';
    $rating = floatval($data['rating'] ?? 5.0);
    $ratingCount = intval($data['ratingCount'] ?? 1);
    $description = $data['description'] ?? '';

    $stmt = $pdo->prepare("INSERT INTO bsk_books 
        (id, slug, title, title_en, author, translator, editor, category_id, category_name, series_id, series_name, price, regular_price, discount_percent, in_stock, stock_quantity, cover_image, cover_theme, edition, pages, isbn, language, rating, rating_count, description) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        title = VALUES(title), author = VALUES(author), price = VALUES(price), regular_price = VALUES(regular_price), in_stock = VALUES(in_stock), cover_image = VALUES(cover_image)");

    $stmt->execute([
        $id, $slug, $title, $titleEn, $author, $translator, $editor,
        $categoryId, $categoryName, $seriesId, $seriesName, $price,
        $regularPrice, $discountPercent, $inStock, $stockQuantity,
        $coverImage, $coverTheme, $edition, $pages, $isbn, $language,
        $rating, $ratingCount, $description
    ]);

    echo json_encode(['status' => 'success', 'message' => 'Book added successfully', 'id' => $id]);
    exit();
}

// -----------------------------------------------------------------------------
// PUT: Update Book or Price / Stock
// -----------------------------------------------------------------------------
if ($method === 'PUT') {
    $id = $_GET['id'] ?? null;
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$id && isset($data['id'])) {
        $id = $data['id'];
    }

    if (!$id || !$data) {
        http_response_code(400);
        echo json_encode(['error' => 'Book ID and update payload required']);
        exit();
    }

    $fields = [];
    $params = [];

    if (isset($data['title'])) { $fields[] = "title = ?"; $params[] = $data['title']; }
    if (isset($data['author'])) { $fields[] = "author = ?"; $params[] = $data['author']; }
    if (isset($data['price'])) { $fields[] = "price = ?"; $params[] = floatval($data['price']); }
    if (isset($data['regularPrice'])) { $fields[] = "regular_price = ?"; $params[] = floatval($data['regularPrice']); }
    if (isset($data['discountPercent'])) { $fields[] = "discount_percent = ?"; $params[] = intval($data['discountPercent']); }
    if (isset($data['inStock'])) { $fields[] = "in_stock = ?"; $params[] = $data['inStock'] ? 1 : 0; }
    if (isset($data['coverImage'])) { $fields[] = "cover_image = ?"; $params[] = $data['coverImage']; }
    if (isset($data['categoryName'])) { $fields[] = "category_name = ?"; $params[] = $data['categoryName']; }
    if (isset($data['categoryId'])) { $fields[] = "category_id = ?"; $params[] = $data['categoryId']; }
    if (isset($data['seriesName'])) { $fields[] = "series_name = ?"; $params[] = $data['seriesName']; }
    if (isset($data['seriesId'])) { $fields[] = "series_id = ?"; $params[] = $data['seriesId']; }
    if (isset($data['description'])) { $fields[] = "description = ?"; $params[] = $data['description']; }

    if (empty($fields)) {
        echo json_encode(['status' => 'no_change', 'message' => 'No fields to update']);
        exit();
    }

    $params[] = $id;
    $sql = "UPDATE bsk_books SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode(['status' => 'success', 'message' => 'Book updated successfully', 'id' => $id]);
    exit();
}

// -----------------------------------------------------------------------------
// DELETE: Delete Book
// -----------------------------------------------------------------------------
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Book ID required']);
        exit();
    }

    $stmt = $pdo->prepare("DELETE FROM bsk_books WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode(['status' => 'success', 'message' => 'Book deleted successfully', 'id' => $id]);
    exit();
}
