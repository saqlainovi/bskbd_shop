<?php
/**
 * Bishwo Shahitto Kendro (BSK) Online Bookshop
 * Database Connection & Configuration Module
 * Compatible with cPanel / Apache / LiteSpeed PHP 7.4 - 8.4+
 */

// Enable Error Logging
error_reporting(E_ALL);
ini_set('display_errors', '0');

// CORS Headers for React Frontend
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// =========================================================================
// cPanel ডাটাবেজ কনফিগারেশন (আপনার cPanel ডাটাবেজের তথ্য নিচে দিন)
// =========================================================================
$db_host = 'localhost';
$db_name = 'bskbd_shop';     // আপনার cPanel ডাটাবেজ নাম
$db_user = 'bskbd_shop';     // আপনার cPanel ডাটাবেজ ইউজার
$db_pass = 'bsk@1978';       // আপনার cPanel ডাটাবেজ পাসওয়ার্ড

// পরিবেশ চলক থাকলে অগ্রাধিকার পাবে
if (getenv('DB_NAME')) $db_name = getenv('DB_NAME');
if (getenv('DB_USER')) $db_user = getenv('DB_USER');
if (getenv('DB_PASS')) $db_pass = getenv('DB_PASS');
if (getenv('DB_HOST')) $db_host = getenv('DB_HOST');

$pdo = null;
$db_error = null;

try {
    $dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
    // ডাটাবেজ অফলাইন থাকলে ক্লায়েন্ট লোকাল স্টোরেজে ফলব্যাক করবে
    $pdo = null;
    $db_error = $e->getMessage();
}

function getDbConnection() {
    global $pdo;
    return $pdo;
}

function getDbError() {
    global $db_error;
    return $db_error;
}

function getDbConfig() {
    global $db_host, $db_name, $db_user;
    return [
        'host' => $db_host,
        'database' => $db_name,
        'user' => $db_user
    ];
}
